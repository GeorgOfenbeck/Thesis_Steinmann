package com.baselet;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MainTest {

	@Test
	public void dummyTest() {
		assertEquals(true,true);
	}
}
