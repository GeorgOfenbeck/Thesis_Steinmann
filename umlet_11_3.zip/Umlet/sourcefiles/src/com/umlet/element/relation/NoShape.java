package com.umlet.element.relation;

import java.awt.Rectangle;

@SuppressWarnings("serial")
public class NoShape extends Rectangle {
	public NoShape() {
		super(0, 0, 1, 1);
	}
}
